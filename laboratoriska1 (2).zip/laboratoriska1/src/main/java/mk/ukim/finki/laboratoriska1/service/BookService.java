package mk.ukim.finki.laboratoriska1.service;

import mk.ukim.finki.laboratoriska1.model.Book;
import mk.ukim.finki.laboratoriska1.model.dto.BookDto;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


public interface BookService {
    List<Book> findAll();
    Optional<Book> findById(Long id);
   Book save(Book book);
    Optional<Book> update (Long id, BookDto book);
    void delete(Long id);
    Optional<Book> markAsRented(Long id);
}