package mk.ukim.finki.laboratoriska1.web;

import mk.ukim.finki.laboratoriska1.model.Country;
import mk.ukim.finki.laboratoriska1.model.dto.CountryDto;
import mk.ukim.finki.laboratoriska1.service.CountryService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;


@RestController
@RequestMapping("/api/countries")
public class CountryController {

    private final CountryService countryService;

    public CountryController(CountryService countryService) {
        this.countryService = countryService;
    }

    @GetMapping
    public List<Country> getAllCountries() {
        return countryService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Country> getCountryById(@PathVariable Long id) {
        return countryService.findById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Country> createCountry(@RequestBody CountryDto countryDTO) {
        Country country = new Country(null, countryDTO.getName(), countryDTO.getContinent());
        return ResponseEntity.ok(countryService.save(country));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCountry(@PathVariable Long id) {
        countryService.delete(id);
        return ResponseEntity.ok().build();
    }


}