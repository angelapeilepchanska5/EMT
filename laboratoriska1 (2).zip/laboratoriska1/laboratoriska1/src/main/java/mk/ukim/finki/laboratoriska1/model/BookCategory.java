package mk.ukim.finki.laboratoriska1.model;

public enum BookCategory {
    NOVEL,
    THRILER,
    HISTORY,
    FANTASY,
    BIOGRAPHY,
    CLASSICS,
    DRAMA
}
