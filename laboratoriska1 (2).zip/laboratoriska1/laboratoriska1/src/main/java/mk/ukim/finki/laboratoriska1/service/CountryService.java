package mk.ukim.finki.laboratoriska1.service;

import mk.ukim.finki.laboratoriska1.model.Country;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

public interface CountryService {
    List<Country> findAll();
    Optional<Country> findById(Long id);
    Country save(Country country);
    void delete(Long id);
}