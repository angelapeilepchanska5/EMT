package mk.ukim.finki.laboratoriska1.model;

import lombok.Data;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import jakarta.persistence.*;
@Data
@Entity
public class Author {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String surename;

    @ManyToOne
    private Country country;

    public Author() {

    }

    public Author(Long id, String name, String surename, Country country) {
        this.id = id;
        this.name = name;
        this.surename = surename;
        this.country = country;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setSurname(String surname) {
        this.surename = surename;


    }

    public void setName(String name) {
        this.name = name;
    }



    public void setCountry(Country country) {
        this.country = country;
    }
}
