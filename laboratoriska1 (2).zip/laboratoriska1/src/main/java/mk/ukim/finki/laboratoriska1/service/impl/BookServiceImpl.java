package mk.ukim.finki.laboratoriska1.service.impl;

import mk.ukim.finki.laboratoriska1.model.Author;
import mk.ukim.finki.laboratoriska1.model.Book;
import mk.ukim.finki.laboratoriska1.model.BookCategory;
import mk.ukim.finki.laboratoriska1.model.dto.BookDto;
import mk.ukim.finki.laboratoriska1.repository.BookRepository;
import mk.ukim.finki.laboratoriska1.service.AuthorService;
import mk.ukim.finki.laboratoriska1.service.BookService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookServiceImpl implements BookService {

    private final BookRepository bookRepository;
    private final AuthorService authorService;

    public BookServiceImpl(BookRepository bookRepository, AuthorService authorService) {
        this.bookRepository = bookRepository;
        this.authorService = authorService;
    }

    @Override
    public List<Book> findAll() {
        return bookRepository.findAll();
    }

    @Override
    public Optional<Book> findById(Long id) {
        return bookRepository.findById(id);
    }


    @Override
    public Book save(Book book) {
        return bookRepository.save(book);
    }

    @Override
    public Optional<Book> update(Long id, BookDto book) {
        return bookRepository.findById(id)
                .map(existingBook->{
                    if(book.getName()!=null){
                        existingBook.setName(book.getName());
                    }
                    if(book.getAvaliableCopies()!=null){
                        existingBook.setAvaliableCopies(book.getAvaliableCopies());
                    }
                    if(book.getCategory()!=null){
                        existingBook.setBookCategory(BookCategory.valueOf(book.getCategory().toUpperCase()));
                    }
                    if(book.getAuthor()!=null && authorService.findById(book.getAuthorId()).isPresent()){
                        existingBook.setAuthor(authorService.findById(book.getAuthorId()).get());
                    }
                    return bookRepository.save(existingBook);
                });
    }

    @Override
    public void delete(Long id) {
        bookRepository.deleteById(id);
    }

    @Override
    public Optional<Book> markAsRented(Long id) {
        return bookRepository.findById(id)
                .filter(book -> book.getAvailableCopies() > 0)
                .map(book -> {
                    book.setAvailableCopies(book.getAvailableCopies() - 1);
                    return bookRepository.save(book);
                });
    }
}