package mk.ukim.finki.laboratoriska1.service.impl;

import mk.ukim.finki.laboratoriska1.model.Country;
import mk.ukim.finki.laboratoriska1.repository.CountryRepository;
import org.springframework.stereotype.Service;
import mk.ukim.finki.laboratoriska1.service.CountryService;


import java.util.List;
import java.util.Optional;

@Service
public class CountryServiceImpl implements CountryService {

    private final CountryRepository countryRepository;

    public CountryServiceImpl(CountryRepository countryRepository) {
        this.countryRepository = countryRepository;
    }

    @Override
    public List<Country> findAll() {
        return countryRepository.findAll();
    }

    @Override
    public Optional<Country> findById(Long id) {
        return countryRepository.findById(id);
    }

    @Override
    public Country save(Country country) {
        return countryRepository.save(country);
    }

    @Override
    public void delete(Long id) {
        countryRepository.deleteById(id);
    }
}