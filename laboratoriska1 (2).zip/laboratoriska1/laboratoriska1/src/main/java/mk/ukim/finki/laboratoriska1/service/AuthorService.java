package mk.ukim.finki.laboratoriska1.service;

import mk.ukim.finki.laboratoriska1.model.Author;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

public interface AuthorService {
    List<Author> findAll();
    Optional<Author> findById(Long id);
    Author save(Author author);
    void delete(Long id);
}