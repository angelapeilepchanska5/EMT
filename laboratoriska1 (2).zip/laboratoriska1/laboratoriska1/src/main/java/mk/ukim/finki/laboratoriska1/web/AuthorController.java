package mk.ukim.finki.laboratoriska1.web;

import mk.ukim.finki.laboratoriska1.model.Author;
import mk.ukim.finki.laboratoriska1.model.Country;
import mk.ukim.finki.laboratoriska1.model.dto.AuthorDto;
import mk.ukim.finki.laboratoriska1.service.AuthorService;
import mk.ukim.finki.laboratoriska1.service.CountryService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/authors")
public class AuthorController {

    private final AuthorService authorService;
    private final CountryService countryService;

    public AuthorController(AuthorService authorService, CountryService countryService) {
        this.authorService = authorService;
        this.countryService = countryService;
    }

    @GetMapping
    public List<Author> getAllAuthors() {
        return authorService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Author> getAuthorById(@PathVariable Long id) {
        return authorService.findById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Author> createAuthor(@RequestBody AuthorDto authorDTO) {
        Optional<Country> country = countryService.findById(authorDTO.getCountryId());
        if (country.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        Author author = new Author(null, authorDTO.getName(), authorDTO.getSurname(), country.get());
        return ResponseEntity.ok(authorService.save(author));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Author> updateAuthor(@PathVariable Long id, @RequestBody AuthorDto authorDTO) {
        Optional<Author> existingAuthor = authorService.findById(id);
        Optional<Country> country = countryService.findById(authorDTO.getCountryId());

        if (existingAuthor.isEmpty() || country.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Author author = existingAuthor.get();
        author.setName(authorDTO.getName());
        author.setSurname(authorDTO.getSurname());
        author.setCountry(country.get());

        return ResponseEntity.ok(authorService.save(author));
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAuthor(@PathVariable Long id) {
        if (authorService.findById(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        authorService.delete(id);
        return ResponseEntity.noContent().build();
    }


}