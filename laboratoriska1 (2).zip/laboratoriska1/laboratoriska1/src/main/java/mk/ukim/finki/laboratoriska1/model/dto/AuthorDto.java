package mk.ukim.finki.laboratoriska1.model.dto;

public class AuthorDto {
    private Long id;
    private String name;
    private String surname;
    private Long countryId;

    public AuthorDto(Long id, String name, String surname, Long countryId) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.countryId = countryId;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public Long getCountryId() {
        return countryId;
    }
}
