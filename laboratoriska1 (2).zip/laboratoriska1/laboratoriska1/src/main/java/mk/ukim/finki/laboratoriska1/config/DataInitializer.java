package mk.ukim.finki.laboratoriska1.config;

import jakarta.annotation.PostConstruct;

import mk.ukim.finki.laboratoriska1.model.Author;
import mk.ukim.finki.laboratoriska1.model.Book;
import mk.ukim.finki.laboratoriska1.model.BookCategory;
import mk.ukim.finki.laboratoriska1.model.Country;
import mk.ukim.finki.laboratoriska1.repository.AuthorRepository;
import mk.ukim.finki.laboratoriska1.repository.BookRepository;
import mk.ukim.finki.laboratoriska1.repository.CountryRepository;
import org.springframework.stereotype.Component;
import java.util.List;

@Component
public class DataInitializer {

    private final AuthorRepository authorRepository;
    private final BookRepository bookRepository;
    private final CountryRepository countryRepository;

    public DataInitializer(AuthorRepository authorRepository, BookRepository bookRepository, CountryRepository countryRepository) {
        this.authorRepository = authorRepository;
        this.bookRepository = bookRepository;
        this.countryRepository = countryRepository;
    }

    @PostConstruct
    public void init() {
        Country country1 = new Country(null, "UK", "Europe");
        Country country2 = new Country(null, "USA", "North America");
        countryRepository.saveAll(List.of(country1, country2));

        Author author1 = new Author(null, "George", "Orwell", country1);
        Author author2 = new Author(null, "Mark", "Twain", country2);
        authorRepository.saveAll(List.of(author1, author2));

        Book book1 = new Book(null, "1984", BookCategory.NOVEL, author1, 5);
        Book book2 = new Book(null, "Adventures of Huckleberry Finn", BookCategory.CLASSICS, author2, 3);
        bookRepository.saveAll(List.of(book1, book2));
    }
}
