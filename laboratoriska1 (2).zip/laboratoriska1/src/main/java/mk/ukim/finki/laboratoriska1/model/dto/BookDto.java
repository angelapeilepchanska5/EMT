package mk.ukim.finki.laboratoriska1.model.dto;

import mk.ukim.finki.laboratoriska1.model.Author;

public class BookDto {
    private Long id;
    private String name;
    private String category;
    private Long authorId;
    private Author author;
    private Integer availableCopies;

    public BookDto(Long id, String name, String category, Long authorId, Author author, Integer availableCopies) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.authorId = authorId;
        this.author = author;
        this.availableCopies = availableCopies;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getCategory() {
        return category;
    }

    public Long getAuthorId() {
        return authorId;
    }

    public Integer getAvailableCopies() {
        return availableCopies;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setAuthorId(Long authorId) {
        this.authorId = authorId;
    }

    public void setAvailableCopies(Integer availableCopies) {
        this.availableCopies = availableCopies;
    }

    public Author getAuthor() {
        return author;
    }

    public Integer getAvaliableCopies() {
        return this.availableCopies;
    }

}

