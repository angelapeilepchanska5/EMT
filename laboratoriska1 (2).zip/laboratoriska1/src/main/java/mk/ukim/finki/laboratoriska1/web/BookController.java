package mk.ukim.finki.laboratoriska1.web;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.annotation.Resource;
import mk.ukim.finki.laboratoriska1.model.Author;
import mk.ukim.finki.laboratoriska1.model.Book;
import mk.ukim.finki.laboratoriska1.model.BookCategory;
import mk.ukim.finki.laboratoriska1.model.dto.BookDto;
import mk.ukim.finki.laboratoriska1.service.AuthorService;
import mk.ukim.finki.laboratoriska1.service.BookService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/books")
@CrossOrigin("*")
@SecurityRequirement(name = "basicAuth")

public class BookController {

    private final BookService bookService;
    private final AuthorService authorService;

    public BookController(BookService bookService, AuthorService authorService) {
        this.bookService = bookService;
        this.authorService = authorService;
    }


    @GetMapping
    public List<Book> getAllBooks() {
        return bookService.findAll();
    }


    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        return bookService.findById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PreAuthorize("hasAuthority('ROLE_LIBRARIAN')")
    @PostMapping("/create")
    public ResponseEntity<Book> createBook(@RequestBody BookDto bookDTO) {
        Optional<Author> author = authorService.findById(bookDTO.getAuthorId());
        if (author.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        Book book = new Book(null, bookDTO.getName(), BookCategory.valueOf(bookDTO.getCategory()),
                author.get(), bookDTO.getAvailableCopies());
        return ResponseEntity.ok(bookService.save(book));

    }

    @PreAuthorize("hasAuthority('ROLE_LIBRARIAN')")
    @PutMapping("/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable Long id, @RequestBody BookDto bookDTO) {
        Optional<Book> existingBook = bookService.findById(id);
        Optional<Author> author = authorService.findById(bookDTO.getAuthorId());

        if (existingBook.isEmpty() || author.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Book book = existingBook.get();
        book.setName(bookDTO.getName());
        book.setBookCategory(BookCategory.valueOf(bookDTO.getCategory()));
        book.setAuthor(author.get());
        book.setAvailableCopies(bookDTO.getAvailableCopies());

        return ResponseEntity.ok(bookService.save(book));


    }



    @PreAuthorize("hasAuthority('ROLE_LIBRARIAN')")
    @DeleteMapping("/{id}/delete")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        if (bookService.findById(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        bookService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @PreAuthorize("hasAuthority('ROLE_LIBRARIAN')")

    @PatchMapping("/{id}/rent")
    public ResponseEntity<Book> rentBook(@PathVariable Long id) {
        return bookService.markAsRented(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.badRequest().build());
    }

}
//
//@RestController
//@RequestMapping("/api/books")
//public class BookController {
//
//    private final BookService bookService;
//    private final AuthorService authorService;
//
//    public BookController(BookService bookService, AuthorService authorService) {
//        this.bookService = bookService;
//        this.authorService = authorService;
//    }
//
//    @GetMapping
//    public List<Book> getAllBooks() {
//        return bookService.findAll();
//
//    }
//
//    @GetMapping("/{id}")
//    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
//        return bookService.findById(id)
//                .map(ResponseEntity::ok)
//                .orElseGet(() -> ResponseEntity.notFound().build());
//    }
//
//    @PostMapping
//    public ResponseEntity<Book> createBook(@RequestBody BookDto bookDTO) {
//        Optional<Author> author = authorService.findById(bookDTO.getAuthorId());
//        if (author.isEmpty()) {
//            return ResponseEntity.badRequest().build();
//        }
//
//        Book book = new Book(null, bookDTO.getName(), BookCategory.valueOf(bookDTO.getCategory()),
//                author.get(), bookDTO.getAvailableCopies());
//        return ResponseEntity.ok(bookService.save(book));
//    }
//
//    @PutMapping("/{id}")
//    public ResponseEntity<Book> updateBook(@PathVariable Long id, @RequestBody BookDto bookDTO) {
//        Optional<Book> existingBook = bookService.findById(id);
//        Optional<Author> author = authorService.findById(bookDTO.getAuthorId());
//
//        if (existingBook.isEmpty() || author.isEmpty()) {
//            return ResponseEntity.notFound().build();
//        }
//
//        Book book = existingBook.get();
//        book.setName(bookDTO.getName());
//        book.setBookCategory(BookCategory.valueOf(bookDTO.getCategory()));
//        book.setAuthor(author.get());
//        book.setAvailableCopies(bookDTO.getAvailableCopies());
//
//        return ResponseEntity.ok(bookService.save(book));
//    }
//
//    @DeleteMapping("/{id}")
//    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
//        if (!bookService.findById(id).isPresent()) {
//            return ResponseEntity.notFound().build();
//        }
//        bookService.delete(id);
//        return ResponseEntity.noContent().build();
//    }
//
//    @PatchMapping("/{id}/rent")
//    public ResponseEntity<Book> rentBook(@PathVariable Long id) {
//        return bookService.markAsRented(id)
//                .map(ResponseEntity::ok)
//                .orElseGet(() -> ResponseEntity.badRequest().build());
//    }
//
//
//}