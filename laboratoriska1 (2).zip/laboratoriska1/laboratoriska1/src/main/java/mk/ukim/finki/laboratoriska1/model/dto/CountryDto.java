package mk.ukim.finki.laboratoriska1.model.dto;

public class CountryDto {
    private Long id;
    private String name;
    private String  contitent;

    public CountryDto(Long id, String name, String contitent) {
        this.id = id;
        this.name = name;
        this.contitent = contitent;
    }

    public String getName() {
        return this.name;
    }

    public String getContinent() {
        return this.contitent;
    }
}
